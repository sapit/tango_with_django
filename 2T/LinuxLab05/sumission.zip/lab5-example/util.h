#include <time.h>
#include <stdlib.h>

#define HIST_MAX_SIZE 100

int getMax_Int(int list[], int len); 

void generateRandData(int data[], int len);
