#include <stdio.h>

void printBar(int lengthOfBar);
void printYAxis(int lengthOfAxis); 
