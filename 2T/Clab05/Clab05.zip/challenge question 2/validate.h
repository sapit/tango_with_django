#include<stdio.h>

#ifndef validate_h
#define validate_h
//try to parse input appropriately 
double validate_input(int argc, char * argv[]);
#endif