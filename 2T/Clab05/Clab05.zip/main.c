#include <stdio.h>
#include "bubble.h"

int main()
{
    bubble();
    return 0;
}