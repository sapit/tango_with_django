#ifndef bubble_h
#include <stdio.h>
#include <string.h>
#define bubble_h
void bubble(void);
#endif